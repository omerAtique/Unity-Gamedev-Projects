# air-hockey-3000
A simple Air Hockey 3D game made with Unity 5.6

Player vs AI

![alt text](AirHockey3000Home.jpg "Main Menu")

![alt text](AirHockey3000GamePlay1.jpg "Gameplay")
